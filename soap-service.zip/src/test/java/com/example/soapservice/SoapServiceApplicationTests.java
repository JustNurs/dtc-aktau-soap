package com.example.soapservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
